fn main() {
    println!("Advent Of Code! 🎅");
}
