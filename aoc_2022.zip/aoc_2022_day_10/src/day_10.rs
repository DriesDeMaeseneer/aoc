use std::io::BufRead;

use std::collections::VecDeque;
use tools::get_file;
use crate::tools;

pub fn signal_thing(file_name: &str) -> i32 {
    // get data file.
    let reader = get_file(file_name);

    let mut queue: VecDeque<i32>= VecDeque::new();
    let mut x_register = 1;
    let mut total = 0;

    // parse each line.
    reader.lines().map(Result::unwrap).for_each(|line| {
        let mut line = line.split_whitespace();
        let first_part = line.next().unwrap();
        match first_part{
            "addx" => {
                let val = line.next().unwrap().parse().unwrap();
                queue.push_back(0);
                queue.push_back(val);
            },
            "noop"=> {
                queue.push_back(0)

            }
            _ => println!("unsuported operation {first_part}")
        }
    });

    // signal strenght for these cycles:
    let mut cur_signal = 0;
    let signals_to_check = [20, 60, 100, 140, 180, 220];


    for i in 0..6{

        while cur_signal < signals_to_check[i] - 1{
            cur_signal += 1;
            x_register += queue.pop_front().unwrap();
        }
        total += x_register * signals_to_check[i];
    }
    total
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    pub fn example() {
        // top = 1, get max elf.
        assert_eq!(13140, signal_thing("example_day_10.input"));
    }
    #[test]
    pub fn puzzle() {
        assert_eq!(11720, signal_thing("day_10.input"));
    }
}
