# aoc
My advent of code code. 

## Before you read my code!
Solve the challenge yourself, that is the best way to learn!
When cheating, you only cheat yourself.

## Resources:

[AOC](https://adventofcode.com/2022/)

[Support AOC](https://adventofcode.com/2022/support)

## Completed:

- [x] Day 1 - rust.
- [x] Day 2 - bash.
- [x] Day 3 - ruby.
- [x] Day 4 - r.
- [x] Day 5 - python.
- [x] Day 6 - algol.
- [x] Day 7 - c.
- [ ] Day 8 - go.
- [ ] Day 9 - sql.
- [ ] Day 10 - assembly.
- [ ] Day 11 - lua.
- [ ] Day 12 - zig.
- [ ] Day 13 - kotlin.
- [ ] Day 14 - haskell.
- [ ] Day 15 - ada.
- [ ] Day 16 - scratch.
- [ ] Day 17 - php.
- [ ] Day 18 - javascript.
- [ ] Day 19 - typescript.
- [ ] Day 20 - java.
- [ ] Day 21 - c++.
- [ ] Day 22 - perl.
- [ ] Day 23 - .
- [ ] Day 24 - .
- [ ] Day 25 - .

## Solution time:

- Day 1: +-20 minutes.
- Day 2: +-120 minutes.
- Day 3: +-40 minutes.
- Day 4: +-80 minutes.
- Day 5: +-15 minutes.
- Day 6: +-150 minutes.
- Day 7: +-150 minutes.
- Day 8: - .
- Day 9: - .
- Day 10: - .
- Day 11: - .
- Day 12: - .
- Day 13: - .
- Day 14: - .
- Day 15: - .
- Day 16: - .
- Day 17: - .
- Day 18: - .
- Day 19: - .
- Day 20: - .
- Day 21: - .
- Day 22: - .
- Day 23: - .
- Day 24: - .
- Day 25: - .
